<?php

declare(strict_types=1);

namespace Calculator\Node;

final class Number extends Literal
{
    public int $value;

    public function __construct(int $value)
    {
        $this->value = $value;
    }
}
