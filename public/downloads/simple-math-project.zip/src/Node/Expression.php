<?php

declare(strict_types=1);

namespace Calculator\Node;

use Phplrt\Contracts\Ast\NodeInterface;

abstract class Expression implements NodeInterface
{
    public function getIterator(): \Traversable
    {
        return new \EmptyIterator();
    }
}
