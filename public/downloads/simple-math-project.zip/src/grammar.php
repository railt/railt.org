<?php
return [
    'initial' => 1,
    'tokens' => [
        'default' => [
            'number' => '\\d+',
            'plus' => '\\+',
            'whitespace' => '\\s+',
        ],
    ],
    'skip' => [
        'whitespace',
    ],
    'transitions' => [
        
    ],
    'grammar' => [
        2 => new \Phplrt\Parser\Grammar\Lexeme('plus', false),
        3 => new \Phplrt\Parser\Grammar\Concatenation([2, 1]),
        4 => new \Phplrt\Parser\Grammar\Optional(3),
        1 => new \Phplrt\Parser\Grammar\Concatenation([0, 4]),
        0 => new \Phplrt\Parser\Grammar\Lexeme('number', true)
    ],
    'reducers' => [
        1 => function (\Phplrt\Parser\Context $ctx, $children) {
            // in case of "$children" sequence is a "number()" and "expression()"
            if (count($children) === 2) {
                return new \Calculator\Node\Addition($children[0], $children[1]);
            }
    
            // otherwise
            return $children;
        },
        0 => function (\Phplrt\Parser\Context $ctx, $children) {
            $token = $ctx->getToken();
            return new \Calculator\Node\Number((int)$token->getValue());
        }
    ]
];